XMenu RVGL Chaos 0.1.0.2
========================

Trainer menu + Chaos Mod for RVGL 23.1030a1 (64-bit).

Credits:      sinaosal
Main idea:    Zolika1351 (ZMenu RVGL Chaos)
Playtesters:  sinaosal, bonczy

The images and sounds in XMenuAssets, except cat.bmp, come from
Zolika1351's original ZMenu RVGL Chaos.


WHAT'S IN THIS ZIP
------------------
rvgl_win64\version.dll           small loader; RVGL loads it automatically
rvgl_win64\XMenu.dll             the mod
rvgl_assets\XMenuAssets\         images and sounds for Chaos effects


INSTALL - RVGL Launcher (rvmm)
------------------------------
1. Close RVGL.
2. Open %LOCALAPPDATA%\rvmm\packs
3. Copy the "rvgl_win64" and "rvgl_assets" folders from this zip into it.
   When Windows asks, choose to merge the folders and replace files.
   Don't copy this README into the packs folder.

If your pack list doesn't use "rvgl_assets", put the XMenuAssets folder
in %LOCALAPPDATA%\rvmm\packs\local instead.

If a launcher update replaces rvgl_win64, copy the two DLLs again.


INSTALL - standalone RVGL folder (rvgl.exe in the game folder)
--------------------------------------------------------------
Copy everything inside "rvgl_win64" and everything inside "rvgl_assets"
into the RVGL folder, next to rvgl.exe.


UPDATING FROM AN OLDER BUILD OR FROM THE ORIGINAL ZMENU
-------------------------------------------------------
- Older builds of this mod were a single version.dll. The new version.dll
  replaces it. The leftover version.exp, version.lib and version.pdb
  files in rvgl_win64 are not needed and can be deleted.
- The original ZMenu (version.dll + ZMenuRVGL.asi + bass.dll +
  zmods_twitch.dll): delete those files first.
- Your settings (ZMenuRVGL.ini and the ZMenu folder) are kept and reused.
- XMenuAssets replaces the old ZMenuAssets folder. If you have one, you
  can delete it.


REMOVE
------
Delete version.dll and XMenu.dll from the rvgl.exe folder
(rvmm: packs\rvgl_win64). The game is then completely vanilla again.

Optional: also delete these settings and log files. With rvmm they are
in %LOCALAPPDATA%\rvmm.
- ZMenuRVGL.ini
- the ZMenu folder
- ZChaosEffectLog.log

Also optional: delete the XMenuAssets folder (rvmm: packs\rvgl_assets).


KEYS (default)
--------------
F7               open / close the menu
Numpad 8 / 2     up / down
Numpad 4 / 6     change value
Numpad 5         select
Numpad 0         back
F6               airbreak (W/S up/down, Numpad 8/2/4/6 move)

Keys can be changed in ZMenuRVGL.ini ([Keybinds], Windows VK codes).


NOTES
-----
- Only RVGL 23.1030a1 is fully supported. On other versions the menu
  opens, but the game features stay off for safety.
- "Unlock Global Car Limit" (up to 512 cars) takes effect after you
  restart RVGL.
- "30 Opponents Support" and "Clockwork Carnage Race Grid" take effect
  right away.
- Multiplayer: when you host or join an online lobby, XMenu locks itself.
  The menu can't be opened, and every cheat and Chaos effect is switched
  off until you leave the session. "30 Opponents Support" and "Clockwork
  Carnage Race Grid" go back to normal in the lobby and return after you
  leave.
- The game's rvgl.exe is never modified. Log file: ZMenu\ZMenuLog.txt
